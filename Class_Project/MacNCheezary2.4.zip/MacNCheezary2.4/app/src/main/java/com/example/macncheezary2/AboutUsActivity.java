package com.example.macncheezary2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class AboutUsActivity extends AppCompatActivity
{

    private Button btnAHome;
    private Button btnACheckOut;
    private Button btnAMenu;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_us);

        btnAHome = findViewById(R.id.btnAHome);
        btnAHome.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                openHomeActivity();
            }
        });

        btnAMenu = findViewById(R.id.btnAMenu);
        btnAMenu.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                openMenuActivity();
            }
        });

        btnACheckOut = findViewById(R.id.btnACheckOut);
        btnACheckOut.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                openCheckOutActivity();
            }
        });

    }

    public void openHomeActivity()
    {
        Intent intent = new Intent(this, HomeActivity.class);
        startActivity(intent);
    }

    public void openMenuActivity()
    {
        Intent intent = new Intent(this, MenuActivity.class);
        startActivity(intent);
    }

    public void openCheckOutActivity()
    {
        Intent intent = new Intent(this, CheckOutActivity.class);
        startActivity(intent);
    }
}
