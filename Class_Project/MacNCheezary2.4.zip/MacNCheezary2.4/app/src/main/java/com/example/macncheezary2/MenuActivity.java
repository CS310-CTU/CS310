package com.example.macncheezary2;

import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

public class MenuActivity extends AppCompatActivity
{

    ListView myListView;
    String[] items;
    String[] prices;
    String[] descriptions;
    private Button btnHome;
    private Button btnCheckOut;
    private Button btnAboutUs;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        btnHome = findViewById(R.id.btnHome);
        btnHome.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                openHomeActivity();
            }
        });

        btnAboutUs = findViewById(R.id.btnAboutUs);
        btnAboutUs.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                openAboutUsActivity();
            }
        });

        btnCheckOut = findViewById(R.id.btnCheckOut);
        btnCheckOut.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                openCheckOutActivity();
            }
        });

        Resources res = getResources();
        myListView = (ListView) findViewById(R.id.myListView);
        items = res.getStringArray(R.array.items);
        prices = res.getStringArray(R.array.prices);
        descriptions = res.getStringArray(R.array.descriptions);

        ItemAdapter itemAdapter = new ItemAdapter(this, items, prices, descriptions);
        myListView.setAdapter(itemAdapter);



        myListView.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                Intent showPictureActivity = new Intent(getApplicationContext(), PictureActivity.class);
                showPictureActivity.putExtra("com.example.macncheezary2.ITEM_INDEX", position);
                startActivity(showPictureActivity);

            }
        });
    }

    public void openHomeActivity()
    {
        Intent intent = new Intent(this, HomeActivity.class);
        startActivity(intent);
    }

    public void openAboutUsActivity()
    {
        Intent intent = new Intent(this, AboutUsActivity.class);
        startActivity(intent);
    }

    public void openCheckOutActivity()
    {
        Intent intent = new Intent(this, CheckOutActivity.class);
        startActivity(intent);
    }
}
