package com.example.macncheezarypocver1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class homeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        final Button menuActivity = (Button)findViewById(R.id.btnMenu);
        menuActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent(getApplicationContext(), menuActivity.class);
                startActivity(startIntent);
            }
        });

        final Button checkoutActivity = (Button)findViewById(R.id.btnCheckOut);
        checkoutActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent(getApplicationContext(), checkoutActivity.class);
                startActivity(startIntent);
            }
        });

        final Button accountActivity = (Button)findViewById(R.id.btnAccount);
        accountActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent(getApplicationContext(), accountActivity.class);
                startActivity(startIntent);
            }
        });

        final Button infoActivity = (Button)findViewById(R.id.btnAboutUs);
        infoActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent(getApplicationContext(), infoActivity.class);
                startActivity(startIntent);
            }
        });

    }
}
