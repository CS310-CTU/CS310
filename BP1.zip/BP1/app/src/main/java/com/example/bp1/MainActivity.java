package com.example.bp1;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Button btn = findViewById(R.id.btnAtHomeMom);
        btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Log.i("MyApp", "These are the Products");
                Toast.makeText(getApplicationContext(), "Dr. Browns Original Bottles, Pampers swaddlers," +
                        "Graco Verb travel system, Graco Everywhere Soother ", Toast.LENGTH_LONG)
                        .show();
            }
        });
        {
            btn = findViewById(R.id.btnGreenMom);
            btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Log.i("MyApp","Green Products");
                    Toast.makeText(getApplicationContext(),"Wash it Later Soak and Save bags, ALVABABY cloth diapers," +
                            "Lifefactory glass bottles, Koolstuffs Natural bamboo bottle brush", Toast.LENGTH_LONG)
                            .show();
                }
            });
            btn=findViewById(R.id.btnWorkingMom);
            btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Log.i("MyApp","WorkingMomProducts");
                    Toast.makeText(getApplicationContext(),"Comotomo Bottles, Medela Pump In Style, " +
                            "Doona Infant Car Seat and base, Amazon Echo Show", Toast.LENGTH_LONG)
                            .show();
                }
            });

        }


        }
    }


